import { useState, useRef, useEffect } from "react";

const LOGO_URL = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48Y2lyY2xlIGN4PSI1MCIgY3k9IjUwIiByPSI0OCIgZmlsbD0iIzFBOEM3QSIvPjx0ZXh0IHg9IjUwIiB5PSI1NSIgZm9udC1zaXplPSIyMiIgZmlsbD0id2hpdGUiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJzYW5zLXNlcmlmIiBmb250LXdlaWdodD0iYm9sZCI+TVNIPC90ZXh0Pjwvc3ZnPg==";
const Icon = {
  home:     <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>,
  patients: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>,
  appts:    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>,
  chat:     <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>,
  profile:  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
  phone:    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.4 2 2 0 0 1 3.6 1.21h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.72a16 16 0 0 0 6 6l.87-.87a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>,
  address:  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>,
  blood:    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>,
  height:   <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="2" x2="12" y2="22"/><polyline points="17 7 12 2 7 7"/><polyline points="7 17 12 22 17 17"/></svg>,
  weight:   <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>,
  calendar: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>,
  heart:    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>,
  pulse:    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>,
  baby:     <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="8" r="5"/><path d="M12 13v9"/><path d="M9 19l3 3 3-3"/></svg>,
  alert:    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>,
  key:      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>,
  mail:     <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>,
  clock:    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>,
  bed:      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 4v16"/><path d="M2 8h18a2 2 0 0 1 2 2v10"/><path d="M2 17h20"/><path d="M6 8v9"/></svg>,
  hospital: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>,
  bag:      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>,
  users:    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>,
  food:     <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8h1a4 4 0 0 1 0 8h-1"/><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"/><line x1="6" y1="1" x2="6" y2="4"/><line x1="10" y1="1" x2="10" y2="4"/><line x1="14" y1="1" x2="14" y2="4"/></svg>,
  pill:     <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10.5 20H4a2 2 0 0 1-2-2V5c0-1.1.9-2 2-2h3.93a2 2 0 0 1 1.66.9l.82 1.2a2 2 0 0 0 1.66.9H20a2 2 0 0 1 2 2v2.5"/><circle cx="16.5" cy="17.5" r="4.5"/><line x1="16.5" y1="15.5" x2="16.5" y2="19.5"/><line x1="14.5" y1="17.5" x2="18.5" y2="17.5"/></svg>,
  search:   <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
  menu:     <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>,
  back:     <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>,
  send:     <svg width="16" height="16" viewBox="0 0 24 24" fill="white" stroke="white" strokeWidth="1"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>,
  edit:     <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>,
  trash:    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>,
  logout:   <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>,
  doctor:   <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/><path d="M12 11v4m-2-2h4"/></svg>,
  patient:  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="7" r="4"/><path d="M5.5 21c0-3.5 3-5 6.5-5s6.5 1.5 6.5 5"/><path d="M12 14v3"/><path d="M10 17h4"/></svg>,
  progress: <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>,
  cross:    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
  plus:     <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  check:    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>,
  star:     <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
};
const DOCTOR_USERS = {
  doctor1: { name: "Dr. Likitha Reddy", specialty: "Obstetrician–Gynaecologist", phone: "9848012345", hospital: "Mother's Safe Hospital, Hyderabad", experience: "15+ Years", patients: "1,200+", quals: ["MBBS – Osmania Medical College, 2008","MD (OBG) – Gandhi Hospital, 2012","Fellowship in Maternal–Fetal Medicine, 2014"], about: "Dr. Likitha Reddy has 15+ years in obstetrics and gynaecology, specialising in high-risk pregnancies." },
  doctor2: { name: "Dr. Meera Patel", specialty: "Gynaecologist", phone: "9912345678", hospital: "Mother's Safe Hospital, Hyderabad", experience: "12+ Years", patients: "900+", quals: ["MBBS – AIIMS Delhi, 2010","MS (OBG) – JIPMER, 2014"], about: "Dr. Meera Patel specialises in gynaecology, antenatal care, and laparoscopic procedures." },
};
const DOCTOR_PASSWORDS = { doctor1: "doctor123", doctor2: "doctor456" };
const HOSPITAL_INFO = { name: "Mother's Safe Hospital", address: "Plot 42, Madhapur, Hyderabad – 500081", phone: "040-2345-6789", emergency: "1800-MSH-HELP (24/7)", email: "care@motherssafe.in", hours: "Mon–Sat: 8 AM – 8 PM | Sun: 9 AM – 2 PM", founded: "2004", beds: "150 beds" };
const HOSPITAL_SPECIALTIES = ["High-Risk Obstetrics","Maternal–Fetal Medicine","Neonatal ICU","Gynaecology","Lactation Support"];
const HOSPITAL_DOCTORS_LIST = [{ name: "Dr. Likitha Reddy", spec: "Obstetrician–Gynaecologist", exp: "15+ yrs" },{ name: "Dr. Meera Patel", spec: "Gynaecologist", exp: "12+ yrs" },{ name: "Dr. Arjun Sharma", spec: "Neonatologist", exp: "10+ yrs" }];
const SEED_PAT_CREDS = {
  patient1: { password: "pat123", patId: 1, docKey: "doctor1", name: "Priya Sharma" },
  sita1:    { password: "sita123", patId: 10, docKey: "doctor2", name: "Sita Rao" },
};
const SEED_DATA = {
  doctor1: {
    patients: [
      { id: 1, name: "Priya Sharma", age: 28, phone: "9876543210", alt: "9876001234", emg: "Rahul Sharma – Husband", height: 162, weight: 68.5, week: 32, blood: "B+", edd: "2024-08-15", addr: "Hyderabad", bpCategory: "normal",
        vitals: [{ date: "2024-01-10", sys: 118, dia: 76, wt: 62, hr: 78, fhr: 142, notes: "Normal" },{ date: "2024-03-05", sys: 132, dia: 85, wt: 65.2, hr: 82, fhr: 148, notes: "BP borderline" },{ date: "2024-05-01", sys: 120, dia: 78, wt: 68.5, hr: 79, fhr: 152, notes: "All normal" }],
        diet: [{ text: "Oats with banana & milk", time: "7:30 AM" },{ text: "Lentil soup with brown rice", time: "1:00 PM" },{ text: "Roti, sabzi, curd", time: "8:30 PM" }],
        meds: [{ text: "Folic Acid 5mg – once daily", time: "Morning" },{ text: "Iron + Folic tablet", time: "After lunch" },{ text: "Calcium 500mg", time: "Bedtime" }],
        username: "patient1" },
      { id: 2, name: "Anita Desai", age: 31, phone: "9812345678", alt: "", emg: "Suresh Desai – Husband", height: 158, weight: 72, week: 20, blood: "A+", edd: "2024-11-10", addr: "Secunderabad", bpCategory: "critical",
        vitals: [{ date: "2024-03-10", sys: 125, dia: 82, wt: 68, hr: 84, fhr: 140, notes: "First visit" },{ date: "2024-05-10", sys: 142, dia: 92, wt: 72, hr: 88, fhr: 145, notes: "BP critical" }],
        diet: [{ text: "Low sodium diet", time: "All day" },{ text: "Fresh fruits", time: "Morning" }],
        meds: [{ text: "Labetalol 100mg", time: "Morning & Evening" },{ text: "Aspirin 75mg", time: "Night" }],
        username: "anita2" },
    ],
    appointments: [
      { id: "a1", patId: 1, patName: "Priya Sharma", reason: "Routine checkup", prefDate: "2024-06-15", prefTime: "10:00", notes: "", status: "accepted", assignedDate: "2024-06-15", assignedTime: "10:00 AM", denyReason: "" },
      { id: "a2", patId: 2, patName: "Anita Desai", reason: "BP monitoring", prefDate: "2024-06-16", prefTime: "11:00", notes: "", status: "pending", assignedDate: "", assignedTime: "", denyReason: "" },
    ],
    messages: {
      1: [{ text: "Hello Priya! How are you feeling today?", from: "doctor", time: "9:00 AM" },{ text: "Hi doctor, I have mild swelling in my feet.", from: "patient", time: "9:15 AM" }],
      2: [{ text: "Anita, please monitor your BP daily and log readings.", from: "doctor", time: "10:00 AM" }],
    },
  },
  doctor2: {
    patients: [{ id: 10, name: "Sita Rao", age: 29, phone: "9900112233", alt: "", emg: "", height: 160, weight: 60, week: 28, blood: "O+", edd: "2024-09-01", addr: "Chennai", bpCategory: "normal",
      vitals: [{ date: "2024-04-01", sys: 120, dia: 78, wt: 58, hr: 80, fhr: 145, notes: "Normal" }],
      diet: [{ text: "Balanced diet with iron-rich foods", time: "All meals" }],
      meds: [{ text: "Folic Acid 5mg", time: "Morning" }],
      username: "sita1" }],
    appointments: [],
    messages: { 10: [] },
  },
};
const BP_CATEGORIES = {
  normal:   { label: "Normal",   color: "#2A7A52", bg: "#EBF8F2" },
  highbp:   { label: "High BP",  color: "#9A5A18", bg: "#FDF2E5" },
  critical: { label: "Critical", color: "#A03040", bg: "#FDEDF0" },
};
function bpStatus(sys) {
  if (sys >= 140) return BP_CATEGORIES.critical;
  if (sys >= 130) return BP_CATEGORIES.highbp;
  return BP_CATEGORIES.normal;
}
function bpFromCategory(cat) { return BP_CATEGORIES[cat] || BP_CATEGORIES.normal; }
function nowTime() {
  const n = new Date(); let h = n.getHours(), m = n.getMinutes();
  const ap = h >= 12 ? "PM" : "AM"; h = h % 12 || 12;
  return `${h}:${m.toString().padStart(2,"0")} ${ap}`;
}
function uuid() { return Math.random().toString(36).slice(2) + Date.now().toString(36); }
const C = {
  teal: "#2BB5A0", tealDark: "#1A8C7A", tealDarker: "#0F6358",
  tealLight: "#E2F5F2", tealLighter: "#F0FAFA",
  green: "#3DAA70", greenLight: "#EBF8F2",
  orange: "#E89240", orangeLight: "#FDF2E5",
  rose: "#E06070", roseLight: "#FDEDF0",
  purple: "#7B68CA", purpleLight: "#EEF0FD",
  bg: "#EDF6F5", white: "#FFFFFF",
  text: "#1A2B38", sub: "#647A8E", border: "#C9EAE6",
  darkBg1: "#0a2a24", darkBg2: "#0f3d35",
};
const styles = `
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'DM Sans', sans-serif; background: #f0f4f3; color: ${C.text}; }
  .phone-shell {
    position: relative; width: 390px; min-height: 844px; flex-shrink: 0;
    background: linear-gradient(175deg, #1c1c1e 0%, #0d0d0f 12%, #111113 25%, #0a0a0c 40%, #131315 55%, #0c0c0e 70%, #1a1a1c 85%, #0e0e10 100%);
    border-radius: 50px; padding: 10px;
    box-shadow: 0 0 0 0.5px rgba(255,255,255,0.18), 0 0 0 1px rgba(0,0,0,0.95),
      inset 0 1.5px 0 rgba(255,255,255,0.13),
      0 40px 80px rgba(0,0,0,0.22);
    margin: auto;
  }
  .btn-silent { position: absolute; left: -3px; top: 88px; width: 3px; height: 28px; background: #1a1a1c; border-radius: 2px 0 0 2px; }
  .btn-vol-up { position: absolute; left: -3px; top: 130px; width: 3px; height: 36px; background: #1a1a1c; border-radius: 2px 0 0 2px; }
  .btn-vol-down { position: absolute; left: -3px; top: 180px; width: 3px; height: 36px; background: #1a1a1c; border-radius: 2px 0 0 2px; }
  .btn-power { position: absolute; right: -3px; top: 148px; width: 3px; height: 74px; background: #1a1a1c; border-radius: 0 2px 2px 0; }
  .phone-bezel { position: relative; width: 100%; background: #000; border-radius: 41px; overflow: hidden; }
  .status-bar { height: 50px; z-index: 9999; display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; padding: 12px 20px 0; background: linear-gradient(135deg, ${C.tealDarker}, ${C.tealDark}); }
  .status-time { font-size: 14px; font-weight: 700; color: rgba(0,0,0,0.85); letter-spacing: -0.3px; justify-self: start; }
  .status-pill { width: 120px; height: 32px; background: #000; border-radius: 18px; justify-self: center; margin-top: -12px; position: relative; z-index: 10000; }
  .status-right { display: flex; align-items: center; gap: 6px; justify-self: end; }
  .home-indicator { height: 34px; display: flex; align-items: flex-end; justify-content: center; padding-bottom: 8px; background: white; }
  .home-bar { width: 130px; height: 5px; background: rgba(0,0,0,0.2); border-radius: 3px; }
  .app { background: ${C.bg}; }
  input, textarea, select { font-family: 'DM Sans', sans-serif; }
  button { cursor: pointer; font-family: 'DM Sans', sans-serif; }
  ::-webkit-scrollbar { width: 0; }
  .screen { display: flex; flex-direction: column; min-height: 760px; max-height: 760px; overflow: hidden; }
  .gradient-dark { background: linear-gradient(160deg, ${C.darkBg1}, ${C.darkBg2}, #0d2d26); }
  .gradient-main { background: linear-gradient(135deg, ${C.tealDarker}, ${C.tealDark}); }
  .appbar { padding: 10px 12px; display: flex; align-items: center; gap: 8px; flex-shrink: 0; }
  .appbar-action { background: none; border: none; color: white; font-size: 12px; font-weight: 700; padding: 4px 8px; display:flex; align-items:center; gap:4px; }
  .icon-btn { background: none; border: none; color: white; padding: 4px; display:flex; align-items:center; justify-content:center; }
  .card { background: white; border-radius: 14px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
  .card-m { margin: 5px 12px; }
  .badge { display: inline-flex; align-items: center; padding: 3px 10px; border-radius: 20px; font-size: 10px; font-weight: 700; white-space: nowrap; }
  .tab-bar { background: white; display: flex; border-bottom: 1px solid ${C.border}; flex-shrink: 0; }
  .tab-item { flex: 1; padding: 11px 4px; text-align: center; font-size: 11px; font-weight: 700; border-bottom: 2px solid transparent; color: ${C.sub}; cursor: pointer; transition: all 0.2s; text-transform: capitalize; }
  .tab-item.active { color: ${C.tealDark}; border-bottom-color: ${C.tealDark}; }
  .tile { display: flex; align-items: center; gap: 12px; padding: 11px 14px; cursor: pointer; transition: background 0.15s; }
  .tile:hover { background: #f5fffe; }
  .avatar { border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; background: ${C.tealLight}; color: ${C.tealDark}; flex-shrink: 0; font-size: 14px; }
  .sec-hdr { font-size: 10px; font-weight: 700; color: ${C.sub}; letter-spacing: 0.5px; padding: 10px 14px 3px; text-transform: uppercase; }
  .ifield { width: 100%; padding: 10px 12px; border: 1.5px solid ${C.border}; border-radius: 10px; font-size: 13px; background: white; outline: none; transition: border 0.2s; color: ${C.text}; }
  .ifield:focus { border-color: ${C.teal}; }
  .ilabel { font-size: 11px; color: ${C.sub}; font-weight: 600; margin-bottom: 3px; display: block; }
  .btn { border: none; border-radius: 12px; padding: 12px 20px; font-size: 13px; font-weight: 700; width: 100%; transition: opacity 0.2s; cursor: pointer; display:flex; align-items:center; justify-content:center; gap:6px; }
  .btn:hover { opacity: 0.88; }
  .btn-teal  { background: ${C.tealDark}; color: white; }
  .btn-green { background: ${C.green}; color: white; }
  .btn-red   { background: ${C.rose}; color: white; }
  .btn-grey  { background: #b0bec5; color: white; }
  .bnav { background: white; display: flex; border-top: 1px solid ${C.border}; padding: 5px 0 4px; flex-shrink: 0; }
  .bnav-item { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 2px; padding: 3px; cursor: pointer; font-size: 9px; font-weight: 600; color: ${C.sub}; transition: color 0.2s; }
  .bnav-item.active { color: ${C.tealDark}; }
  .bnav-icon { display:flex; align-items:center; justify-content:center; }
  .drawer-ov { position: absolute; inset: 0; background: rgba(0,0,0,0.45); z-index: 100; }
  .drawer { position: absolute; left: 0; top: 0; bottom: 0; width: 250px; background: white; z-index: 101; display: flex; flex-direction: column; animation: slideIn 0.22s ease; overflow-y: auto; }
  @keyframes slideIn { from { transform: translateX(-100%); } to { transform: translateX(0); } }
  .d-hdr { padding: 24px 16px 14px; }
  .d-item { display: flex; align-items: center; gap: 10px; padding: 12px 16px; font-size: 13px; font-weight: 600; color: ${C.text}; border: none; background: none; width: 100%; text-align: left; cursor: pointer; transition: background 0.12s; }
  .d-item:hover { background: ${C.tealLighter}; }
  .d-item.active { color: ${C.tealDark}; background: ${C.tealLight}; }
  .d-sep { height: 1px; background: ${C.border}; margin: 4px 0; }
  .modal-ov { position: absolute; inset: 0; background: rgba(0,0,0,0.38); z-index: 200; display: flex; align-items: flex-end; }
  .modal-sheet { background: white; border-radius: 20px 20px 0 0; width: 100%; padding: 18px; max-height: 80%; overflow-y: auto; animation: slideUp 0.22s ease; }
  @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
  .modal-handle { width: 36px; height: 4px; background: #ddd; border-radius: 2px; margin: 0 auto 14px; }
  .irow { display: flex; align-items: flex-start; gap: 10px; padding: 8px 14px; border-bottom: 1px solid ${C.border}; }
  .irow:last-child { border-bottom: none; }
  .irow-lbl { font-size: 10px; color: ${C.sub}; font-weight: 600; }
  .irow-val { font-size: 12px; font-weight: 600; color: ${C.text}; }
  .vcard { background: white; border-radius: 12px; padding: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
  .vval { font-size: 20px; font-weight: 700; color: ${C.text}; }
  .vunit { font-size: 10px; color: ${C.sub}; }
  .vlbl { font-size: 10px; color: ${C.sub}; margin-top: 1px; }
  .dmcard { background: white; border-radius: 11px; box-shadow: 0 1px 6px rgba(0,0,0,0.05); margin: 3px 12px; padding: 10px 12px; display: flex; align-items: center; gap: 9px; }
  .tchip { padding: 3px 8px; border-radius: 8px; background: ${C.tealLighter}; color: ${C.tealDark}; font-size: 10px; font-weight: 600; flex-shrink: 0; }
  .toast { position: absolute; bottom: 66px; left: 50%; transform: translateX(-50%); color: white; padding: 9px 18px; border-radius: 20px; font-size: 12px; font-weight: 600; z-index: 500; white-space: nowrap; animation: fadeUp 0.2s ease; }
  @keyframes fadeUp { from { opacity:0; transform: translateX(-50%) translateY(8px); } to { opacity:1; transform: translateX(-50%) translateY(0); } }
  .empty { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 44px 20px; color: ${C.sub}; text-align: center; }
  .empty-icon { margin-bottom: 10px; opacity: 0.4; }
  .empty-txt { font-size: 12px; line-height: 1.6; }
  .wkcard { margin: 6px 12px; background: white; border-radius: 14px; padding: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
  .wkbar { height: 7px; background: ${C.tealLight}; border-radius: 4px; margin-top: 8px; overflow: hidden; }
  .wkfill { height: 100%; background: linear-gradient(90deg, ${C.teal}, ${C.tealDark}); border-radius: 4px; transition: width 0.5s; }
  .psec { margin: 6px 12px 0; background: white; border-radius: 14px; box-shadow: 0 1px 8px rgba(0,0,0,0.05); overflow: hidden; }
  .psec-hdr { padding: 8px 14px; border-bottom: 1px solid ${C.border}; font-size: 10px; font-weight: 700; color: ${C.tealDark}; letter-spacing: 0.5px; text-transform: uppercase; }
  .vcrd { background: white; border-radius: 12px; box-shadow: 0 1px 6px rgba(0,0,0,0.05); margin: 3px 12px; padding: 11px; }
  .vrow { display: flex; margin-bottom: 3px; font-size: 11px; }
  .vrow-l { width: 75px; color: ${C.sub}; }
  .vrow-v { font-weight: 600; color: ${C.text}; }
  .pcard { padding: 16px; border-radius: 16px; border: 1.5px solid; margin-bottom: 12px; display: flex; align-items: center; gap: 12px; cursor: pointer; background: rgba(255,255,255,0.07); transition: opacity 0.2s; }
  .pcard:hover { opacity: 0.85; }
  .pcard-icon { width: 48px; height: 48px; border-radius: 13px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
  .search-wrap { padding: 8px 12px; background: ${C.bg}; position: relative; }
  .search-inp { width: 100%; padding: 8px 12px 8px 34px; border: 1.5px solid ${C.border}; border-radius: 20px; font-size: 12px; background: white; outline: none; color: ${C.text}; }
  .search-inp:focus { border-color: ${C.teal}; }
  .search-icon { position: absolute; left: 22px; top: 50%; transform: translateY(-50%); color: ${C.sub}; pointer-events: none; display:flex; align-items:center; }
  .bp-pills { display: flex; gap: 6px; margin-top: 4px; }
  .bp-pill { flex: 1; padding: 7px 4px; border-radius: 10px; border: 1.5px solid; text-align: center; font-size: 11px; font-weight: 700; cursor: pointer; transition: all 0.15s; }
  .chip-tag { display: inline-flex; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
  .icon-circle { width: 32px; height: 32px; border-radius: 50%; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
`;

export default function App() {
  const [data, setData] = useState(JSON.parse(JSON.stringify(SEED_DATA)));
  const [patCreds, setPatCreds] = useState(JSON.parse(JSON.stringify(SEED_PAT_CREDS)));
  const [screen, setScreen] = useState("portal");
  const [currentDoc, setCurrentDoc] = useState(null);
  const [currentPat, setCurrentPat] = useState(null);
  const [toast, setToast] = useState(null);
  const [time, setTime] = useState(nowTime);
  useEffect(() => { const t = setInterval(() => setTime(nowTime()), 15000); return () => clearInterval(t); }, []);
  function showToast(msg, color = C.tealDark) { setToast({ msg, color }); setTimeout(() => setToast(null), 2500); }
  function loginDoctor(user, pass) { if (DOCTOR_PASSWORDS[user] === pass) { setCurrentDoc(user); setScreen("doctor"); return true; } return false; }
  function loginPatient(user, pass) { const cred = patCreds[user]; if (cred && cred.password === pass) { setCurrentPat({ ...cred, username: user }); setScreen("patient"); return true; } return false; }
  function logout() { setCurrentDoc(null); setCurrentPat(null); setScreen("portal"); }
  const docData = currentDoc ? data[currentDoc] : null;
  const patData = currentPat ? (data[currentPat.docKey]?.patients.find(p => p.id === currentPat.patId) || null) : null;
  const patMessages = currentPat ? (data[currentPat.docKey]?.messages[currentPat.patId] || []) : [];
  const patAppointments = currentPat ? (data[currentPat.docKey]?.appointments.filter(a => a.patId === currentPat.patId) || []) : [];
  function updateDoc(fn) { setData(d => { const nd = JSON.parse(JSON.stringify(d)); fn(nd[currentDoc]); return nd; }); }
  function addPatient(p, username, password) {
    updateDoc(d => { d.patients.push(p); if (!d.messages[p.id]) d.messages[p.id] = []; });
    setPatCreds(c => ({ ...c, [username]: { password, patId: p.id, docKey: currentDoc, name: p.name, patEmail: p.patEmail || (username + "@patient.motherssafe.com") } }));
  }
  function removePatient(pid) {
    const pat = docData.patients.find(p => p.id === pid);
    if (pat?.username) setPatCreds(c => { const nc = { ...c }; delete nc[pat.username]; return nc; });
    updateDoc(d => { d.patients = d.patients.filter(p => p.id !== pid); });
  }
  function addVital(pid, v) {
    updateDoc(d => {
      const p = d.patients.find(p => p.id === pid);
      if (p) {
        // Append vital and write back bpCategory derived from systolic (IA Criterion C – Code 12, bpStatus())
        p.vitals.push(v);
        p.bpCategory = v.sys >= 140 ? "critical" : v.sys >= 130 ? "highbp" : "normal";
      }
    });
  }
  function updateDiet(pid, diet) { updateDoc(d => { const p = d.patients.find(p => p.id === pid); if (p) p.diet = diet; }); }
  function updateMeds(pid, meds) { updateDoc(d => { const p = d.patients.find(p => p.id === pid); if (p) p.meds = meds; }); }
  function acceptAppt(id, date, time) { updateDoc(d => { const a = d.appointments.find(a => a.id === id); if (a) { a.status = "accepted"; a.assignedDate = date; a.assignedTime = time; } }); }
  function denyAppt(id, reason) { updateDoc(d => { const a = d.appointments.find(a => a.id === id); if (a) { a.status = "denied"; a.denyReason = reason; } }); }
  function doctorSend(pid, text) { updateDoc(d => { if (!d.messages[pid]) d.messages[pid] = []; d.messages[pid].push({ text, from: "doctor", time: nowTime() }); }); }
  function patientSend(text) { setData(d => { const nd = JSON.parse(JSON.stringify(d)); const dd = nd[currentPat.docKey]; if (!dd.messages[currentPat.patId]) dd.messages[currentPat.patId] = []; dd.messages[currentPat.patId].push({ text, from: "patient", time: nowTime() }); return nd; }); }
  function bookAppt(a) { setData(d => { const nd = JSON.parse(JSON.stringify(d)); nd[currentPat.docKey].appointments.push(a); return nd; }); }
  const ctx = { screen, setScreen, currentDoc, currentPat, docData, patData, patMessages, patAppointments, loginDoctor, loginPatient, logout, showToast, patCreds, addPatient, removePatient, addVital, updateDiet, updateMeds, acceptAppt, denyAppt, doctorSend, patientSend, bookAppt };
  return (
    <>
      <style>{styles}</style>
      <div style={{ minHeight:"100vh", background:"#f0f4f3", display:"flex", alignItems:"center", justifyContent:"center", padding:"40px 20px" }}>
        <div className="phone-shell">
          <div className="btn-silent" /><div className="btn-vol-up" /><div className="btn-vol-down" /><div className="btn-power" />
          <div className="phone-bezel">
            <div className="status-bar">
              <span className="status-time">{time}</span>
              <div className="status-pill" />
              <div className="status-right">
                <svg width="17" height="12" viewBox="0 0 17 12"><rect x="0" y="8" width="3" height="4" rx="0.5" fill="rgba(0,0,0,0.7)"/><rect x="4.5" y="5.5" width="3" height="6.5" rx="0.5" fill="rgba(0,0,0,0.7)"/><rect x="9" y="3" width="3" height="9" rx="0.5" fill="rgba(0,0,0,0.7)"/><rect x="13.5" y="0" width="3" height="12" rx="0.5" fill="rgba(0,0,0,0.7)"/></svg>
                <svg width="26" height="13" viewBox="0 0 26 13"><rect x="0.75" y="0.75" width="22" height="11.5" rx="2.5" stroke="rgba(0,0,0,0.6)" strokeWidth="1.5" fill="none"/><rect x="23.25" y="4" width="2.5" height="5" rx="1.25" fill="rgba(0,0,0,0.5)"/><rect x="2.25" y="2.25" width="18" height="8.5" rx="1.5" fill="rgba(0,0,0,0.75)"/></svg>
              </div>
            </div>
            <div style={{ position:"relative" }}>
              <div className="app">
                {screen === "portal"    && <PortalScreen ctx={ctx} />}
                {screen === "doc-login" && <DocLoginScreen ctx={ctx} />}
                {screen === "pat-login" && <PatLoginScreen ctx={ctx} />}
                {screen === "doctor"    && <DoctorApp ctx={ctx} />}
                {screen === "patient"   && <PatientApp ctx={ctx} />}
                {toast && <div className="toast" style={{ background: toast.color }}>{toast.msg}</div>}
              </div>
            </div>
            <div className="home-indicator"><div className="home-bar" /></div>
          </div>
        </div>
      </div>
    </>
  );
}

function PortalScreen({ ctx }) {
  return (
    <div className="screen gradient-dark" style={{ overflowY:"auto", padding:"0 24px", paddingTop:28 }}>
      <div style={{ display:"flex", flexDirection:"column", alignItems:"center", marginBottom:28 }}>
        <div style={{ width:96, height:96, borderRadius:22, background:"white", display:"flex", alignItems:"center", justifyContent:"center", boxShadow:`0 0 28px rgba(43,181,160,0.4)`, marginBottom:12, overflow:"hidden", padding:6 }}>
          <img src={LOGO_URL} alt="MSH" style={{ width:"100%", height:"100%", objectFit:"contain" }} />
        </div>
        <h1 style={{ color:"white", fontSize:20, fontWeight:700, textAlign:"center", lineHeight:1.2 }}>Mother's Safe Hospital</h1>
        <p style={{ color:"rgba(255,255,255,0.5)", fontSize:11, marginTop:3 }}>Prenatal Care Management</p>
        <div style={{ marginTop:8, padding:"3px 12px", borderRadius:20, border:`1px solid rgba(43,181,160,0.4)`, background:`rgba(43,181,160,0.15)`, display:"flex", alignItems:"center", gap:5 }}>
          <div style={{ width:6, height:6, borderRadius:3, background:C.green }} />
          <span style={{ color:"#7DE8DA", fontSize:9, fontWeight:700, letterSpacing:0.7 }}>LIVE SYSTEM</span>
        </div>
      </div>
      <p style={{ color:"rgba(255,255,255,0.55)", fontSize:11, fontWeight:600, textAlign:"center", marginBottom:12 }}>Choose Your Portal</p>
      {[
        { iconEl:<span style={{color:"white"}}>{Icon.doctor}</span>, title:"Doctor Portal", sub:"Manage patients, appointments & records", action:() => ctx.setScreen("doc-login") },
        { iconEl:<span style={{color:"white"}}>{Icon.patient}</span>, title:"Patient Portal", sub:"View health records & message your doctor", action:() => ctx.setScreen("pat-login") },
      ].map(item => (
        <div key={item.title} className="pcard" style={{ borderColor:`rgba(43,181,160,0.35)` }} onClick={item.action}>
          <div className="pcard-icon" style={{ background:C.tealDark }}>{item.iconEl}</div>
          <div style={{ flex:1 }}>
            <div style={{ color:"white", fontSize:14, fontWeight:700 }}>{item.title}</div>
            <div style={{ color:"rgba(255,255,255,0.5)", fontSize:10, marginTop:2 }}>{item.sub}</div>
          </div>
          <span style={{ color:"rgba(255,255,255,0.35)", fontSize:18 }}>›</span>
        </div>
      ))}
    </div>
  );
}

function DocLoginScreen({ ctx }) {
  const [user, setUser] = useState(""); const [pass, setPass] = useState(""); const [err, setErr] = useState(false); const [sp, setSp] = useState(false);
  return (
    <LoginLayout title="Doctor Portal" onBack={() => ctx.setScreen("portal")}>
      <LoginForm user={user} pass={pass} sp={sp} err={err} onUser={v => { setUser(v); setErr(false); }} onPass={v => { setPass(v); setErr(false); }} onToggle={() => setSp(s => !s)} onLogin={() => { if (!ctx.loginDoctor(user, pass)) setErr(true); }} errMsg="Invalid credentials." demos={[["Dr. Likitha Reddy","doctor1","doctor123"],["Dr. Meera Patel","doctor2","doctor456"]]} onFill={(u,p) => { setUser(u); setPass(p); setErr(false); }} />
    </LoginLayout>
  );
}
function PatLoginScreen({ ctx }) {
  const [user, setUser] = useState(""); const [pass, setPass] = useState(""); const [err, setErr] = useState(false); const [sp, setSp] = useState(false);
  return (
    <LoginLayout title="Patient Portal" onBack={() => ctx.setScreen("portal")}>
      <LoginForm user={user} pass={pass} sp={sp} err={err} onUser={v => { setUser(v); setErr(false); }} onPass={v => { setPass(v); setErr(false); }} onToggle={() => setSp(s => !s)} onLogin={() => { if (!ctx.loginPatient(user, pass)) setErr(true); }} errMsg="Invalid credentials." demos={[["Priya Sharma","patient1","pat123"],["Sita Rao","sita1","sita123"]]} onFill={(u,p) => { setUser(u); setPass(p); setErr(false); }} />
    </LoginLayout>
  );
}
function LoginLayout({ title, children, onBack }) {
  return (
    <div className="screen gradient-dark" style={{ overflowY:"auto", padding:"0 22px", paddingTop:30 }}>
      <div style={{ textAlign:"center", marginBottom:18 }}>
        <div style={{ width:72, height:72, borderRadius:18, background:"white", margin:"0 auto 10px", display:"flex", alignItems:"center", justifyContent:"center", overflow:"hidden", padding:4, boxShadow:"0 4px 20px rgba(0,0,0,0.25)" }}>
          <img src={LOGO_URL} alt="MSH" style={{ width:"100%", height:"100%", objectFit:"contain" }} />
        </div>
        <div style={{ color:"white", fontSize:18, fontWeight:700 }}>Mother's Safe</div>
        <div style={{ color:"rgba(255,255,255,0.5)", fontSize:11 }}>{title}</div>
      </div>
      {children}
      <button onClick={onBack} style={{ background:"none", border:"none", color:"rgba(255,255,255,0.5)", fontSize:12, display:"flex", alignItems:"center", gap:4, margin:"12px auto 16px", cursor:"pointer" }}>
        <span style={{ color:"rgba(255,255,255,0.5)" }}>{Icon.back}</span> Back to Portal Selection
      </button>
    </div>
  );
}
function LoginForm({ user, pass, sp, err, onUser, onPass, onToggle, onLogin, errMsg, demos, onFill }) {
  return (
    <div style={{ background:"white", borderRadius:18, padding:16, boxShadow:"0 10px 36px rgba(0,0,0,0.2)" }}>
      <div style={{ fontSize:14, fontWeight:700, marginBottom:12 }}>Sign In</div>
      <label className="ilabel">Username</label>
      <input className="ifield" value={user} onChange={e => onUser(e.target.value)} style={{ marginBottom:9 }} />
      <label className="ilabel">Password</label>
      <div style={{ position:"relative" }}>
        <input className="ifield" type={sp ? "text" : "password"} value={pass} onChange={e => onPass(e.target.value)} onKeyDown={e => e.key === "Enter" && onLogin()} />
        <button onClick={onToggle} style={{ position:"absolute", right:10, top:"50%", transform:"translateY(-50%)", background:"none", border:"none", color:C.sub, fontSize:11, fontWeight:700 }}>{sp ? "HIDE" : "SHOW"}</button>
      </div>
      {err && <div style={{ background:C.roseLight, color:C.rose, padding:"6px 10px", borderRadius:8, fontSize:11, marginTop:6 }}>{errMsg}</div>}
      <button className="btn btn-teal" style={{ marginTop:12 }} onClick={onLogin}>{Icon.check} Sign In</button>
      <div style={{ background:C.tealLighter, borderRadius:9, border:`1px solid ${C.border}`, padding:9, marginTop:10 }}>
        <div style={{ fontSize:9, color:C.sub, fontWeight:700, marginBottom:6, textTransform:"uppercase", letterSpacing:0.4 }}>Demo — tap to fill</div>
        {demos.map(([name, u, p]) => (
          <div key={u} onClick={() => onFill(u, p)} style={{ display:"flex", alignItems:"center", gap:5, marginBottom:4, cursor:"pointer" }}>
            <span style={{ flex:1, fontSize:10, fontWeight:600, color:C.tealDark }}>{name}</span>
            {[u, p].map(t => <span key={t} style={{ background:C.tealLight, color:C.tealDarker, padding:"2px 6px", borderRadius:5, fontSize:9, fontWeight:700 }}>{t}</span>)}
          </div>
        ))}
      </div>
    </div>
  );
}

function DoctorApp({ ctx }) {
  const [tab, setTab] = useState("dash");
  const [drawerOpen, setDrawer] = useState(false);
  const [sub, setSub] = useState(null);
  const doc = DOCTOR_USERS[ctx.currentDoc];
  const dd  = ctx.docData;
  if (sub?.type === "patient") return <PatientProfile patient={sub.patient} ctx={ctx} onBack={() => setSub(null)} />;
  if (sub?.type === "add-pat") return <AddPatientScreen ctx={ctx} onBack={() => setSub(null)} />;
  if (sub?.type === "chat")    return <ChatScreen name={sub.patient.name} msgs={dd.messages[sub.patient.id]||[]} onSend={t => ctx.doctorSend(sub.patient.id, t)} isDoctor onBack={() => setSub(null)} />;
  if (sub?.type === "doc-pro") return <DocProfileScreen doc={doc} onBack={() => setSub(null)} />;
  if (sub?.type === "hosp")    return <HospitalInfoScreen onBack={() => setSub(null)} />;
  return (
    <div className="screen">
      {drawerOpen && <Drawer isDoctor name={doc.name} sub={doc.specialty} tab={tab} onTab={t => { setTab(t); setDrawer(false); }} onProfile={() => { setSub({ type:"doc-pro" }); setDrawer(false); }} onHosp={() => { setSub({ type:"hosp" }); setDrawer(false); }} onLogout={ctx.logout} onClose={() => setDrawer(false)} />}
      <div style={{ flex:1, overflowY:"auto", WebkitOverflowScrolling:"touch", paddingBottom:52 }}>
        {tab === "dash"  && <DashTab    dd={dd} doc={doc} setSub={setSub} openDrawer={() => setDrawer(true)} />}
        {tab === "pats"  && <PatientsTab dd={dd} setSub={setSub} openDrawer={() => setDrawer(true)} />}
        {tab === "appts" && <ApptsTab   dd={dd} ctx={ctx} openDrawer={() => setDrawer(true)} />}
        {tab === "msgs"  && <DoctorMsgsTab dd={dd} setSub={setSub} openDrawer={() => setDrawer(true)} />}
      </div>
      <BottomNav items={[["dash",Icon.home,"Home"],["pats",Icon.patients,"Patients"],["appts",Icon.appts,"Appts"],["msgs",Icon.chat,"Chat"]]} tab={tab} onTab={setTab} />
    </div>
  );
}

function DashTab({ dd, doc, setSub, openDrawer }) {
  const pending  = dd.appointments.filter(a => a.status === "pending").length;
  const accepted = dd.appointments.filter(a => a.status === "accepted").length;
  return (
    <div>
      <Appbar title="Dashboard" onMenu={openDrawer} actions={<button className="appbar-action" onClick={() => setSub({ type:"add-pat" })}>{Icon.plus} Patient</button>} />
      <div onClick={() => setSub({ type:"doc-pro" })} style={{ margin:"8px 12px", padding:14, borderRadius:14, background:"linear-gradient(135deg,#0D3D36,#1A8C7A)", cursor:"pointer", display:"flex", alignItems:"center", gap:12 }}>
        <div style={{ width:44, height:44, borderRadius:12, background:"rgba(255,255,255,0.14)", border:"1px solid rgba(255,255,255,0.25)", display:"flex", alignItems:"center", justifyContent:"center", color:"white" }}>{Icon.doctor}</div>
        <div>
          <div style={{ color:"white", fontSize:14, fontWeight:700 }}>{doc.name}</div>
          <div style={{ color:"rgba(255,255,255,0.6)", fontSize:10 }}>{doc.specialty}</div>
          <div style={{ color:"rgba(255,255,255,0.38)", fontSize:9 }}>Tap to view profile →</div>
        </div>
      </div>
      <div style={{ display:"flex", gap:7, margin:"0 12px" }}>
        {[[dd.patients.length,"Patients",C.tealDark],[pending,"Pending",C.orange],[accepted,"Confirmed",C.green]].map(([v,l,c]) => (
          <div key={l} style={{ flex:1, background:"white", borderRadius:11, padding:"11px 6px", textAlign:"center", boxShadow:"0 2px 8px rgba(0,0,0,0.05)" }}>
            <div style={{ fontSize:20, fontWeight:700, color:c }}>{v}</div>
            <div style={{ fontSize:9, color:C.sub }}>{l}</div>
          </div>
        ))}
      </div>
      <div className="sec-hdr">Patients</div>
      {dd.patients.slice(0,3).map(p => <PatTile key={p.id} p={p} onClick={() => setSub({ type:"patient", patient:p })} />)}
      {!dd.patients.length && <Empty icon={Icon.patients} msg="No patients yet." />}
      <div className="sec-hdr">Recent Appointments</div>
      {dd.appointments.slice(0,3).map(a => <ApptPill key={a.id} a={a} />)}
      {!dd.appointments.length && <Empty icon={Icon.appts} msg="No appointments yet." />}
    </div>
  );
}

function PatientsTab({ dd, setSub, openDrawer }) {
  const [filter, setFilter] = useState("all");
  const [q, setQ] = useState("");
  const filters = [
    { key:"all", label:"All", color:C.tealDark, bg:C.tealLight },
    { key:"normal", label:"Normal", color:C.green, bg:C.greenLight },
    { key:"highbp", label:"High BP", color:"#9A5A18", bg:"#FDF2E5" },
    { key:"critical", label:"Critical", color:C.rose, bg:C.roseLight },
  ];
  const filtered = dd.patients.filter(p => (!q || p.name.toLowerCase().includes(q.toLowerCase())) && (filter === "all" || p.bpCategory === filter));
  return (
    <div>
      <Appbar title="My Patients" onMenu={openDrawer} actions={<button className="appbar-action" onClick={() => setSub({ type:"add-pat" })}>{Icon.plus} Add</button>} />
      <div className="search-wrap">
        <span className="search-icon">{Icon.search}</span>
        <input className="search-inp" placeholder="Search patients…" value={q} onChange={e => setQ(e.target.value)} />
      </div>
      <div style={{ display:"flex", gap:5, padding:"4px 12px 8px", overflowX:"auto" }}>
        {filters.map(f => (
          <div key={f.key} onClick={() => setFilter(f.key)} style={{ padding:"4px 12px", borderRadius:20, border:`1.5px solid ${filter===f.key ? f.color : C.border}`, background: filter===f.key ? f.bg : "white", color: filter===f.key ? f.color : C.sub, fontSize:11, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap", flexShrink:0 }}>
            {f.label}
          </div>
        ))}
      </div>
      {!filtered.length ? <Empty icon={Icon.patients} msg="No patients found." /> : filtered.map(p => <PatTile key={p.id} p={p} onClick={() => setSub({ type:"patient", patient:p })} />)}
    </div>
  );
}

function DoctorMsgsTab({ dd, setSub, openDrawer }) {
  const [q, setQ] = useState("");
  const filtered = dd.patients.filter(p => p.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <div>
      <Appbar title="Messages" onMenu={openDrawer} />
      <div className="search-wrap">
        <span className="search-icon">{Icon.search}</span>
        <input className="search-inp" placeholder="Search patients…" value={q} onChange={e => setQ(e.target.value)} />
      </div>
      {!filtered.length ? <Empty icon={Icon.chat} msg="No patients found." /> : filtered.map(p => {
        const msgs = dd.messages[p.id] || [];
        const last = msgs[msgs.length - 1];
        const unread = msgs.filter(m => m.from === "patient").length;
        return (
          <div key={p.id} className="card card-m tile" onClick={() => setSub({ type:"chat", patient:p })}>
            <div className="avatar" style={{ width:40, height:40 }}>{p.name[0]}</div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontWeight:700, fontSize:13 }}>{p.name}</div>
              <div style={{ fontSize:11, color:C.sub, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{last ? last.text : "No messages yet"}</div>
            </div>
            {unread > 0 && <div style={{ background:C.tealDark, color:"white", borderRadius:10, minWidth:18, height:18, display:"flex", alignItems:"center", justifyContent:"center", fontSize:9, fontWeight:700, padding:"0 4px" }}>{unread}</div>}
          </div>
        );
      })}
    </div>
  );
}

function ApptsTab({ dd, ctx, openDrawer }) {
  const [sel, setSel] = useState(null);
  const [dateV, setDateV] = useState(""); const [timeV, setTimeV] = useState(""); const [denyR, setDenyR] = useState(""); const [showDeny, setShowDeny] = useState(false);
  return (
    <div>
      <Appbar title="Appointments" onMenu={openDrawer} />
      {!dd.appointments.length ? <Empty icon={Icon.appts} msg="No appointments yet." /> :
        dd.appointments.map(a => {
          const [c, bg] = statusColor(a.status);
          return (
            <div key={a.id} className="card card-m tile" onClick={() => { setSel(a); setDateV(""); setTimeV(""); setDenyR(""); setShowDeny(false); }}>
              <div className="avatar" style={{ width:38, height:38, fontSize:13 }}>{a.patName[0]}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontWeight:700, fontSize:13 }}>{a.patName}</div>
                <div style={{ fontSize:10, color:C.sub }}>{a.reason}</div>
                {a.prefDate && <div style={{ fontSize:9, color:C.sub }}>{a.prefDate}{a.prefTime ? ` at ${a.prefTime}` : ""}</div>}
              </div>
              <span className="badge" style={{ background:bg, color:c }}>{a.status}</span>
            </div>
          );
        })
      }
      {sel && (
        <div className="modal-ov" onClick={e => e.target === e.currentTarget && setSel(null)}>
          <div className="modal-sheet">
            <div className="modal-handle" />
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:10 }}>
              <span style={{ fontSize:15, fontWeight:700 }}>{sel.patName}</span>
              <span className="badge" style={{ background:statusColor(sel.status)[1], color:statusColor(sel.status)[0] }}>{sel.status}</span>
            </div>
            <div style={{ background:C.tealLighter, borderRadius:9, padding:11, marginBottom:8 }}>
              <div style={{ fontSize:9, fontWeight:700, color:C.tealDark, marginBottom:3, textTransform:"uppercase" }}>Request</div>
              <div style={{ fontSize:12, fontWeight:700 }}>{sel.reason}</div>
              {sel.notes && <div style={{ fontSize:10, color:C.sub }}>{sel.notes}</div>}
              <div style={{ fontSize:10, color:C.sub }}>Preferred: {sel.prefDate} {sel.prefTime}</div>
            </div>
            {sel.status === "accepted" && <div style={{ background:C.greenLight, borderRadius:9, padding:11, marginBottom:8 }}><div style={{ fontSize:9, fontWeight:700, color:C.green, marginBottom:3 }}>CONFIRMED</div><div style={{ fontWeight:700, color:C.green, fontSize:12 }}>{sel.assignedDate} at {sel.assignedTime}</div></div>}
            {sel.status === "pending" && !showDeny && (
              <>
                <label className="ilabel" style={{ marginTop:8 }}>Confirm Date</label>
                <input className="ifield" placeholder="YYYY-MM-DD" value={dateV} onChange={e => setDateV(e.target.value)} style={{ marginBottom:7 }} />
                <label className="ilabel">Confirm Time</label>
                <input className="ifield" placeholder="10:00 AM" value={timeV} onChange={e => setTimeV(e.target.value)} style={{ marginBottom:11 }} />
                <div style={{ display:"flex", gap:7 }}>
                  <button className="btn btn-green" style={{ flex:1 }} onClick={() => { if (!dateV || !timeV) return; ctx.acceptAppt(sel.id, dateV, timeV); ctx.showToast("Confirmed!", C.green); setSel(null); }}>{Icon.check} Accept</button>
                  <button className="btn btn-red" style={{ flex:1 }} onClick={() => setShowDeny(true)}>Deny</button>
                </div>
              </>
            )}
            {showDeny && (
              <>
                <label className="ilabel" style={{ marginTop:8 }}>Reason for denial</label>
                <input className="ifield" value={denyR} onChange={e => setDenyR(e.target.value)} style={{ marginBottom:11 }} />
                <div style={{ display:"flex", gap:7 }}>
                  <button className="btn btn-grey" style={{ flex:1 }} onClick={() => setShowDeny(false)}>Cancel</button>
                  <button className="btn btn-red" style={{ flex:1 }} onClick={() => { ctx.denyAppt(sel.id, denyR); ctx.showToast("Denied.", C.rose); setSel(null); setShowDeny(false); }}>Deny</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function PatientProfile({ patient: init, ctx, onBack }) {
  const [tab, setTab] = useState("info");
  const [vModal, setVModal] = useState(false);
  const [dietModal, setDiet] = useState(false);
  const [medsModal, setMeds] = useState(false);
  const [rmModal, setRm] = useState(false);
  const patient = ctx.docData?.patients.find(p => p.id === init.id) || init;
  const latest  = patient.vitals[patient.vitals.length - 1];
  const bpLatest = latest ? bpStatus(latest.sys) : bpFromCategory(patient.bpCategory || "normal");
  return (
    <div className="screen">
      <Appbar title={patient.name} onBack={onBack} />
      <div style={{ padding:"14px 18px 14px", background:"linear-gradient(135deg,#0F6358,#1A8C7A)", textAlign:"center", flexShrink:0 }}>
        <div className="avatar" style={{ width:50, height:50, fontSize:18, margin:"0 auto 8px" }}>{patient.name[0]}</div>
        <div style={{ color:"white", fontSize:15, fontWeight:700 }}>{patient.name}</div>
        <div style={{ color:"rgba(255,255,255,0.6)", fontSize:10 }}>{patient.age} yrs · {patient.blood} · Week {patient.week}</div>
        <span className="badge" style={{ background:bpLatest.bg, color:bpLatest.color, marginTop:6, display:"inline-flex" }}>BP: {bpLatest.label}</span>
      </div>
      <div className="tab-bar">
        {["info","vitals","diet","meds"].map(t => <div key={t} className={`tab-item ${tab===t?"active":""}`} onClick={() => setTab(t)}>{t}</div>)}
      </div>
      <div style={{ flex:1, overflowY:"auto", WebkitOverflowScrolling:"touch", paddingBottom:12 }}>
        {tab === "info" && (
          <>
            <div className="psec" style={{ marginTop:8 }}>
              <InfoRow icon={Icon.profile} label="Full Name" value={patient.name} />
              <InfoRow icon={Icon.calendar} label="Age" value={`${patient.age} years`} />
              <InfoRow icon={Icon.phone} label="Phone" value={patient.phone} />
              {patient.alt && <InfoRow icon={Icon.phone} label="Alternate" value={patient.alt} />}
              {patient.emg && <InfoRow icon={Icon.alert} label="Emergency Contact" value={patient.emg} ic={C.rose} />}
              <InfoRow icon={Icon.address} label="Address" value={patient.addr} />
            </div>
            <div className="psec"><InfoRow icon={Icon.key} label="Login Username" value={patient.username || "—"} /></div>
            <WeekProgress week={patient.week} />
            <div className="psec">
              <InfoRow icon={Icon.blood} label="Blood Group" value={patient.blood} />
              <InfoRow icon={Icon.height} label="Height" value={`${patient.height} cm`} />
              <InfoRow icon={Icon.weight} label="Weight" value={`${patient.weight} kg`} />
              <InfoRow icon={Icon.calendar} label="EDD" value={patient.edd} />
            </div>
            <div style={{ margin:"10px 12px 0" }}>
              <button className="btn btn-red" onClick={() => setRm(true)}>{Icon.trash} Remove Patient</button>
            </div>
          </>
        )}
        {tab === "vitals" && (
          <>
            {latest && (
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:7, margin:"8px 12px 0" }}>
                {[
                  { val:`${latest.sys}/${latest.dia}`, unit:"mmHg", lbl:"Blood Pressure", icon:Icon.blood, badge:bpStatus(latest.sys) },
                  { val:`${latest.wt}`, unit:"kg", lbl:"Weight", icon:Icon.weight },
                  { val:`${latest.hr}`, unit:"bpm", lbl:"Heart Rate", icon:Icon.pulse },
                  { val:`${latest.fhr}`, unit:"bpm", lbl:"Fetal HR", icon:Icon.baby },
                ].map((vc,i) => (
                  <div key={i} className="vcard">
                    <div style={{ color:C.tealDark, marginBottom:4 }}>{vc.icon}</div>
                    {vc.badge && <span className="badge" style={{ background:vc.badge.bg, color:vc.badge.color, fontSize:9, marginBottom:3, display:"inline-flex" }}>{vc.badge.label}</span>}
                    <div><span className="vval">{vc.val}</span><span className="vunit"> {vc.unit}</span></div>
                    <div className="vlbl">{vc.lbl}</div>
                  </div>
                ))}
              </div>
            )}
            <div className="sec-hdr">Visit History</div>
            {patient.vitals.map((v,i) => {
              const bs = bpStatus(v.sys);
              return (
                <div key={i} className="vcrd">
                  <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
                    <span style={{ fontWeight:700, fontSize:11 }}>Visit {i+1} · {v.date}</span>
                    <span className="badge" style={{ background:bs.bg, color:bs.color }}>{bs.label}</span>
                  </div>
                  {[["BP",`${v.sys}/${v.dia} mmHg`],["Weight",`${v.wt} kg`],["HR / FHR",`${v.hr} / ${v.fhr} bpm`],v.notes&&["Notes",v.notes]].filter(Boolean).map(([l,val]) => (
                    <div key={l} className="vrow"><span className="vrow-l">{l}</span><span className="vrow-v">{val}</span></div>
                  ))}
                </div>
              );
            })}
            {!patient.vitals.length && <Empty icon={Icon.pulse} msg="No visit records yet." />}
            <div style={{ margin:"8px 12px 0" }}><button className="btn btn-green" onClick={() => setVModal(true)}>{Icon.plus} Log Visit</button></div>
          </>
        )}
        {tab === "diet" && (
          <>
            <DietMedHeader title="Diet Plan" onEdit={() => setDiet(true)} />
            {!patient.diet.length ? <Empty icon={Icon.food} msg="No diet plan yet." /> :
              patient.diet.map((d,i) => (
                <div key={i} className="dmcard" style={{ borderLeft:`3px solid ${[C.tealDark,C.teal,C.green,C.orange][i%4]}` }}>
                  <span style={{ color:C.tealDark }}>{Icon.food}</span>
                  <span style={{ flex:1, fontSize:12, fontWeight:500 }}>{d.text}</span>
                  <span className="tchip">{d.time}</span>
                </div>
              ))
            }
          </>
        )}
        {tab === "meds" && (
          <>
            <DietMedHeader title="Medications" onEdit={() => setMeds(true)} />
            {!patient.meds.length ? <Empty icon={Icon.pill} msg="No medications yet." /> :
              patient.meds.map((m,i) => (
                <div key={i} className="dmcard" style={{ borderLeft:`3px solid ${[C.purple,C.teal,C.tealDark][i%3]}` }}>
                  <span style={{ color:C.purple }}>{Icon.pill}</span>
                  <span style={{ flex:1, fontSize:12, fontWeight:500 }}>{m.text}</span>
                  <span className="tchip" style={{ background:C.purpleLight, color:C.purple }}>{m.time}</span>
                </div>
              ))
            }
          </>
        )}
      </div>
      {vModal    && <AddVitalModal pid={patient.id} ctx={ctx} onClose={() => setVModal(false)} />}
      {dietModal && <EditListModal title="Edit Diet Plan" items={patient.diet} itemLabel="Food item" onSave={items => { ctx.updateDiet(patient.id, items); ctx.showToast("Diet saved!"); setDiet(false); }} onClose={() => setDiet(false)} />}
      {medsModal && <EditListModal title="Edit Medications" items={patient.meds} itemLabel="Medication" onSave={items => { ctx.updateMeds(patient.id, items); ctx.showToast("Medications saved!"); setMeds(false); }} onClose={() => setMeds(false)} />}
      {rmModal && (
        <div className="modal-ov" onClick={e => e.target === e.currentTarget && setRm(false)}>
          <div className="modal-sheet">
            <div className="modal-handle" />
            <div style={{ fontSize:15, fontWeight:700, marginBottom:7 }}>Remove Patient</div>
            <div style={{ fontSize:12, color:C.sub, marginBottom:14 }}>Remove {patient.name}? This cannot be undone.</div>
            <div style={{ display:"flex", gap:7 }}>
              <button className="btn btn-grey" style={{ flex:1 }} onClick={() => setRm(false)}>Cancel</button>
              <button className="btn btn-red" style={{ flex:1 }} onClick={() => { ctx.removePatient(patient.id); ctx.showToast("Removed.", C.rose); onBack(); }}>{Icon.trash} Remove</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function AddPatientScreen({ ctx, onBack }) {
  const [form, setForm] = useState({ name:"", age:"", phone:"", alt:"", emg:"", height:"", weight:"", week:"", blood:"B+", edd:"", addr:"", bpCategory:"normal", username:"", password:"" });
  const f = k => e => setForm(s => ({ ...s, [k]: e.target.value }));
  const bloodGroups = ["A+","A-","B+","B-","O+","O-","AB+","AB-"];
  function save() {
    if (!form.name || !form.age || !form.phone) { ctx.showToast("Name, age & phone required.", C.rose); return; }
    if (!form.username || !form.password) { ctx.showToast("Username & password required.", C.rose); return; }
    if (ctx.patCreds[form.username]) { ctx.showToast("Username already taken!", C.rose); return; }
    const p = { id:Date.now(), name:form.name, age:parseInt(form.age)||0, phone:form.phone, alt:form.alt, emg:form.emg, height:parseFloat(form.height)||160, weight:parseFloat(form.weight)||60, week:parseInt(form.week)||1, blood:form.blood, edd:form.edd, addr:form.addr, bpCategory:form.bpCategory, vitals:[], diet:[], meds:[], username:form.username, patEmail: form.username + "@patient.motherssafe.com" };
    ctx.addPatient(p, form.username, form.password);
    ctx.showToast("Patient added!", C.green);
    onBack();
  }
  const bpOpts = [{ key:"normal", label:"Normal", color:C.green, bg:C.greenLight },{ key:"highbp", label:"High BP", color:"#9A5A18", bg:"#FDF2E5" },{ key:"critical", label:"Critical", color:C.rose, bg:C.roseLight }];
  return (
    <div className="screen">
      <Appbar title="Add Patient" onBack={onBack} />
      <div style={{ flex:1, overflowY:"auto", WebkitOverflowScrolling:"touch", padding:"12px 12px 20px" }}>
        <SectionCard title="Basic Info">
          {[["Full Name *","name","text"],["Age *","age","number"],["Phone *","phone","tel"],["Alt Phone","alt","tel"],["Emergency Contact","emg","text"],["Address","addr","text"]].map(([l,k,t]) => (
            <FieldRow key={k} label={l}><input className="ifield" type={t} value={form[k]} onChange={f(k)} /></FieldRow>
          ))}
        </SectionCard>
        <SectionCard title="Medical Info">
          {[["Height (cm)","height","number"],["Weight (kg)","weight","number"],["Pregnancy Week","week","number"],["EDD (YYYY-MM-DD)","edd","text"]].map(([l,k,t]) => (
            <FieldRow key={k} label={l}><input className="ifield" type={t} value={form[k]} onChange={f(k)} /></FieldRow>
          ))}
          <FieldRow label="Blood Group"><select className="ifield" value={form.blood} onChange={f("blood")}>{bloodGroups.map(b => <option key={b}>{b}</option>)}</select></FieldRow>
          <FieldRow label="BP Category">
            <div className="bp-pills">
              {bpOpts.map(o => (
                <div key={o.key} className="bp-pill" onClick={() => setForm(s => ({ ...s, bpCategory:o.key }))} style={{ borderColor:form.bpCategory===o.key ? o.color : C.border, background:form.bpCategory===o.key ? o.bg : "white", color:form.bpCategory===o.key ? o.color : C.sub }}>{o.label}</div>
              ))}
            </div>
          </FieldRow>
        </SectionCard>
        <SectionCard title="Patient Login Credentials">
          <div style={{ padding:"8px 10px", background:C.tealLighter, borderRadius:8, marginBottom:8, fontSize:10, color:C.sub, lineHeight:1.5 }}>Set username & password the patient will use to log in.</div>
          <FieldRow label="Username *"><input className="ifield" value={form.username} onChange={f("username")} placeholder="e.g. priya2025" /></FieldRow>
          <FieldRow label="Password *"><input className="ifield" value={form.password} onChange={f("password")} placeholder="e.g. priya@123" /></FieldRow>
        </SectionCard>
        <button className="btn btn-teal" style={{ marginTop:4 }} onClick={save}>{Icon.check} Add Patient</button>
      </div>
    </div>
  );
}

function DocProfileScreen({ doc, onBack }) {
  return (
    <div className="screen">
      <Appbar title="My Profile" onBack={onBack} />
      <div style={{ flex:1, overflowY:"auto", WebkitOverflowScrolling:"touch", paddingBottom:16 }}>
        <div style={{ padding:"22px 18px 18px", background:"linear-gradient(135deg,#0D3D36,#1A8C7A)", textAlign:"center" }}>
          <div style={{ width:60, height:60, borderRadius:16, background:"rgba(255,255,255,0.14)", border:"1px solid rgba(255,255,255,0.25)", display:"flex", alignItems:"center", justifyContent:"center", margin:"0 auto 10px", color:"white" }}>{Icon.doctor}</div>
          <div style={{ color:"white", fontSize:17, fontWeight:700 }}>{doc.name}</div>
          <div style={{ color:"rgba(255,255,255,0.6)", fontSize:11 }}>{doc.specialty}</div>
        </div>
        <div className="psec" style={{ marginTop:8 }}>
          <div className="psec-hdr">Hospital & Contact</div>
          <InfoRow icon={Icon.hospital} label="Hospital" value={doc.hospital} />
          <InfoRow icon={Icon.phone} label="Phone" value={doc.phone} />
          <InfoRow icon={Icon.bag} label="Experience" value={doc.experience} />
          <InfoRow icon={Icon.users} label="Patients Served" value={doc.patients} />
        </div>
        <div className="psec">
          <div className="psec-hdr">Qualifications</div>
          {doc.quals.map((q,i) => (
            <div key={i} style={{ display:"flex", gap:8, padding:"8px 14px", borderBottom: i < doc.quals.length-1 ? `1px solid ${C.border}` : "none" }}>
              <div style={{ width:5, height:5, borderRadius:3, background:C.teal, marginTop:5, flexShrink:0 }} />
              <span style={{ fontSize:11, color:C.text, lineHeight:1.4 }}>{q}</span>
            </div>
          ))}
        </div>
        <div className="psec">
          <div className="psec-hdr">About</div>
          <div style={{ padding:14, fontSize:11, color:C.sub, lineHeight:1.6 }}>{doc.about}</div>
        </div>
      </div>
    </div>
  );
}

function PatientApp({ ctx }) {
  const [tab, setTab] = useState("home");
  const [drawerOpen, setDrawer] = useState(false);
  const [sub, setSub] = useState(null);
  const pat = ctx.currentPat;
  const doc = pat ? DOCTOR_USERS[pat.docKey] : null;
  if (sub?.type === "hosp") return <HospitalInfoScreen onBack={() => setSub(null)} />;
  return (
    <div className="screen">
      {drawerOpen && <Drawer isDoctor={false} name={pat.name} sub="Patient" tab={tab} onTab={t => { setTab(t); setDrawer(false); }} onHosp={() => { setSub({ type:"hosp" }); setDrawer(false); }} onLogout={ctx.logout} onClose={() => setDrawer(false)} />}
      <div style={{ flex:1, overflowY:"auto", WebkitOverflowScrolling:"touch", paddingBottom:52 }}>
        {tab === "home"    && <PatHomeTab   patData={ctx.patData} patName={pat.name} openDrawer={() => setDrawer(true)} />}
        {tab === "appts"   && <PatApptsTab  patAppointments={ctx.patAppointments} ctx={ctx} openDrawer={() => setDrawer(true)} />}
        {tab === "chat"    && <PatChatOuter patMessages={ctx.patMessages} ctx={ctx} doc={doc} openDrawer={() => setDrawer(true)} />}
        {tab === "profile" && <PatProfileTab patData={ctx.patData} patName={pat.name} openDrawer={() => setDrawer(true)} />}
      </div>
      <BottomNav items={[["home",Icon.home,"Home"],["appts",Icon.appts,"Appts"],["chat",Icon.chat,"Chat"],["profile",Icon.profile,"Profile"]]} tab={tab} onTab={setTab} />
    </div>
  );
}

function PatHomeTab({ patData: p, patName, openDrawer }) {
  return (
    <div>
      <Appbar title={`Hi, ${patName.split(" ")[0]}!`} onMenu={openDrawer} />
      {!p ? <Empty icon={Icon.profile} msg={"Your doctor hasn't registered\nyour record yet."} /> : (
        <>
          <WeekProgress week={p.week} />
          <div style={{ display:"flex", gap:7, margin:"0 12px 6px" }}>
            {[["Blood",p.blood,C.tealLight,C.tealDark],["Age",`${p.age} yrs`,C.purpleLight,C.purple],["EDD",p.edd,C.greenLight,C.green]].map(([l,v,bg,c]) => (
              <div key={l} style={{ flex:1, background:bg, borderRadius:9, padding:"7px 4px", textAlign:"center" }}>
                <div style={{ fontSize:9, color:`${c}bb`, fontWeight:600 }}>{l}</div>
                <div style={{ fontSize:11, color:c, fontWeight:700 }}>{v}</div>
              </div>
            ))}
          </div>
          {p.vitals.length > 0 && (() => {
            const latest = p.vitals[p.vitals.length-1];
            const bp = bpStatus(latest.sys);
            return (
              <>
                <div className="sec-hdr">Latest Vitals</div>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:7, margin:"0 12px" }}>
                  {[
                    { val:`${latest.sys}/${latest.dia}`, unit:"mmHg", lbl:"Blood Pressure", icon:Icon.blood, badge:bp },
                    { val:`${latest.wt}`, unit:"kg", lbl:"Weight", icon:Icon.weight },
                    { val:`${latest.hr}`, unit:"bpm", lbl:"Heart Rate", icon:Icon.pulse },
                    { val:`${latest.fhr}`, unit:"bpm", lbl:"Fetal HR", icon:Icon.baby },
                  ].map((vc,i) => (
                    <div key={i} className="vcard">
                      <div style={{ color:C.tealDark, marginBottom:4 }}>{vc.icon}</div>
                      {vc.badge && <span className="badge" style={{ background:vc.badge.bg, color:vc.badge.color, fontSize:9, marginBottom:3, display:"inline-flex" }}>{vc.badge.label}</span>}
                      <div><span className="vval" style={{ fontSize:17 }}>{vc.val}</span><span className="vunit"> {vc.unit}</span></div>
                      <div className="vlbl">{vc.lbl}</div>
                    </div>
                  ))}
                </div>
              </>
            );
          })()}
          {p.diet.length > 0 && (<><div className="sec-hdr">Today's Diet Plan</div>{p.diet.map((d,i) => (<div key={i} className="dmcard" style={{ borderLeft:`3px solid ${C.teal}` }}><span style={{ color:C.tealDark }}>{Icon.food}</span><span style={{ flex:1, fontSize:11, fontWeight:500 }}>{d.text}</span><span className="tchip">{d.time}</span></div>))}</>)}
          {p.meds.length > 0 && (<><div className="sec-hdr">Medications</div>{p.meds.map((m,i) => (<div key={i} className="dmcard" style={{ borderLeft:`3px solid ${C.purple}` }}><span style={{ color:C.purple }}>{Icon.pill}</span><span style={{ flex:1, fontSize:11, fontWeight:500 }}>{m.text}</span><span className="tchip" style={{ background:C.purpleLight, color:C.purple }}>{m.time}</span></div>))}</>)}
        </>
      )}
    </div>
  );
}

function PatApptsTab({ patAppointments, ctx, openDrawer }) {
  const [showBook, setShowBook] = useState(false);
  const [sel, setSel] = useState(null);
  const [form, setForm] = useState({ reason:"", date:"", time:"", notes:"" });
  const f = k => e => setForm(s => ({ ...s, [k]: e.target.value }));
  return (
    <div>
      <Appbar title="Appointments" onMenu={openDrawer} actions={<button className="appbar-action" onClick={() => setShowBook(true)}>{Icon.plus} Book</button>} />
      {!patAppointments.length ? <Empty icon={Icon.appts} msg="No appointments yet. Tap + Book." /> :
        patAppointments.map(a => {
          const [c, bg] = statusColor(a.status);
          return (
            <div key={a.id} className="card card-m" style={{ padding:12, cursor:"pointer" }} onClick={() => setSel(a)}>
              <div style={{ display:"flex", alignItems:"center" }}>
                <div style={{ flex:1 }}>
                  <div style={{ fontWeight:700, fontSize:13 }}>{a.reason}</div>
                  {a.prefDate && <div style={{ fontSize:10, color:C.sub }}>Requested: {a.prefDate}{a.prefTime ? ` at ${a.prefTime}` : ""}</div>}
                  {a.status === "accepted" && <div style={{ fontSize:10, color:C.green, fontWeight:700, display:"flex", alignItems:"center", gap:3 }}>{Icon.check} {a.assignedDate} at {a.assignedTime}</div>}
                  {a.status === "denied"   && <div style={{ fontSize:10, color:C.rose }}>Declined: {a.denyReason}</div>}
                  {a.status === "pending"  && <div style={{ fontSize:10, color:C.orange }}>Awaiting confirmation…</div>}
                </div>
                <span className="badge" style={{ background:bg, color:c }}>{a.status}</span>
              </div>
            </div>
          );
        })
      }
      {showBook && (
        <div className="modal-ov" onClick={e => e.target === e.currentTarget && setShowBook(false)}>
          <div className="modal-sheet">
            <div className="modal-handle" />
            <div style={{ fontSize:15, fontWeight:700, marginBottom:12 }}>Book Appointment</div>
            <label className="ilabel">Reason for visit *</label>
            <input className="ifield" value={form.reason} onChange={f("reason")} style={{ marginBottom:8 }} />
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:7, marginBottom:8 }}>
              <div><label className="ilabel">Preferred Date</label><input className="ifield" placeholder="YYYY-MM-DD" value={form.date} onChange={f("date")} /></div>
              <div><label className="ilabel">Preferred Time</label><input className="ifield" placeholder="10:00 AM" value={form.time} onChange={f("time")} /></div>
            </div>
            <label className="ilabel">Additional Notes</label>
            <textarea className="ifield" rows={2} value={form.notes} onChange={f("notes")} style={{ marginBottom:12, resize:"none" }} />
            <button className="btn btn-teal" onClick={() => { if (!form.reason.trim()) return; ctx.bookAppt({ id:uuid(), patId:ctx.currentPat.patId, patName:ctx.currentPat.name, reason:form.reason.trim(), prefDate:form.date.trim(), prefTime:form.time.trim(), notes:form.notes.trim(), status:"pending", assignedDate:"", assignedTime:"", denyReason:"" }); ctx.showToast("Request sent!"); setShowBook(false); setForm({ reason:"", date:"", time:"", notes:"" }); }}>{Icon.check} Submit Request</button>
          </div>
        </div>
      )}
      {sel && (
        <div className="modal-ov" onClick={e => e.target === e.currentTarget && setSel(null)}>
          <div className="modal-sheet">
            <div className="modal-handle" />
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:10 }}>
              <span style={{ fontSize:15, fontWeight:700 }}>Appointment Details</span>
              <span className="badge" style={{ background:statusColor(sel.status)[1], color:statusColor(sel.status)[0] }}>{sel.status}</span>
            </div>
            <div style={{ background:C.tealLighter, borderRadius:9, padding:10, marginBottom:8 }}>
              <div style={{ fontSize:9, fontWeight:700, color:C.tealDark, marginBottom:3 }}>REQUEST</div>
              <div style={{ fontSize:12, fontWeight:700 }}>{sel.reason}</div>
              {sel.notes && <div style={{ fontSize:10, color:C.sub }}>{sel.notes}</div>}
              <div style={{ fontSize:10, color:C.sub }}>Preferred: {sel.prefDate} {sel.prefTime}</div>
            </div>
            <div style={{ background:{ accepted:C.greenLight, denied:C.roseLight, pending:C.orangeLight }[sel.status], borderRadius:9, padding:10 }}>
              <div style={{ fontSize:9, fontWeight:700, color:{ accepted:C.green, denied:C.rose, pending:C.orange }[sel.status], marginBottom:3 }}>STATUS: {sel.status.toUpperCase()}</div>
              {sel.status === "accepted" && <><div style={{ fontWeight:700, color:C.green, fontSize:12 }}>{sel.assignedDate} at {sel.assignedTime}</div><div style={{ fontSize:10, color:C.sub }}>Please arrive 15 minutes early.</div></>}
              {sel.status === "denied"   && <div style={{ fontSize:11, color:C.rose }}>Reason: {sel.denyReason}</div>}
              {sel.status === "pending"  && <div style={{ fontSize:11, color:C.orange }}>Your request is being reviewed.</div>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function PatChatOuter({ patMessages, ctx, doc, openDrawer }) {
  const docName = doc?.name || "Doctor";
  return (
    <div className="screen">
      <Appbar title="Chat with Doctor" onMenu={openDrawer} sub={docName} />
      <ChatScreen name={docName} msgs={patMessages} onSend={t => ctx.patientSend(t)} isDoctor={false} inline />
    </div>
  );
}

function PatProfileTab({ patData: p, patName, openDrawer }) {
  if (!p) return <div><Appbar title="My Profile" onMenu={openDrawer} /><Empty icon={Icon.profile} msg="No record found." /></div>;
  const latest = p.vitals[p.vitals.length-1];
  return (
    <div>
      <Appbar title="My Profile" onMenu={openDrawer} />
      <div style={{ flex:1, overflowY:"auto" }}>
        <div style={{ padding:"18px 18px 14px", background:"linear-gradient(135deg,#0D3D36,#1A8C7A)", textAlign:"center" }}>
          <div style={{ width:52, height:52, borderRadius:14, background:"rgba(255,255,255,0.15)", display:"flex", alignItems:"center", justifyContent:"center", margin:"0 auto 8px", color:"white" }}>{Icon.patient}</div>
          <div style={{ color:"white", fontSize:15, fontWeight:700 }}>{patName}</div>
          <div style={{ color:"rgba(255,255,255,0.6)", fontSize:10 }}>{p.age} yrs · {p.blood} · Week {p.week}</div>
        </div>
        <div className="psec" style={{ marginTop:8 }}>
          <div className="psec-hdr">Personal Info</div>
          <InfoRow icon={Icon.phone} label="Phone" value={p.phone} />
          <InfoRow icon={Icon.address} label="Address" value={p.addr} />
          <InfoRow icon={Icon.blood} label="Blood Group" value={p.blood} />
          <InfoRow icon={Icon.height} label="Height" value={`${p.height} cm`} />
          <InfoRow icon={Icon.weight} label="Weight" value={`${p.weight} kg`} />
          <InfoRow icon={Icon.calendar} label="EDD" value={p.edd} />
        </div>
        <WeekProgress week={p.week} />
        {latest && (
          <div className="psec">
            <div className="psec-hdr">Latest Vitals</div>
            <InfoRow icon={Icon.blood} label="Blood Pressure" value={`${latest.sys}/${latest.dia} mmHg`} />
            <InfoRow icon={Icon.weight} label="Weight" value={`${latest.wt} kg`} />
            <InfoRow icon={Icon.pulse} label="Heart Rate" value={`${latest.hr} bpm`} />
            <InfoRow icon={Icon.baby} label="Fetal HR" value={`${latest.fhr} bpm`} />
          </div>
        )}
      </div>
    </div>
  );
}

function ChatScreen({ name, msgs, onSend, isDoctor, onBack, inline }) {
  const [text, setText] = useState("");
  const bottomRef = useRef(null);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior:"smooth" }); }, [msgs.length]);
  function send() { if (!text.trim()) return; onSend(text.trim()); setText(""); }
  const content = (
    <>
      <div style={{ flex:1, overflowY:"auto", WebkitOverflowScrolling:"touch", padding:"10px 10px 4px" }}>
        {msgs.length === 0 && <div style={{ textAlign:"center", color:C.sub, fontSize:11, marginTop:30 }}>No messages yet. Say hello!</div>}
        {msgs.map((m, i) => {
          const mine = isDoctor ? m.from === "doctor" : m.from === "patient";
          return (
            <div key={i} style={{ display:"flex", justifyContent:mine ? "flex-end" : "flex-start", marginBottom:5 }}>
              {!mine && <div style={{ width:22, height:22, borderRadius:"50%", background:C.tealLight, display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, marginRight:5, alignSelf:"flex-end", flexShrink:0 }}>{name[0]}</div>}
              <div style={{ maxWidth:"74%", padding:"8px 11px", borderRadius:mine ? "13px 13px 2px 13px" : "13px 13px 13px 2px", background:mine ? C.tealDark : "white", color:mine ? "white" : C.text, boxShadow:"0 1px 5px rgba(0,0,0,0.08)" }}>
                <div style={{ fontSize:12, lineHeight:1.4 }}>{m.text}</div>
                <div style={{ fontSize:9, color:mine ? "rgba(255,255,255,0.5)" : C.sub, marginTop:2, textAlign:"right" }}>{m.time}</div>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>
      <div style={{ padding:"7px 9px", background:"white", borderTop:`1px solid ${C.border}`, display:"flex", gap:7, alignItems:"center", flexShrink:0 }}>
        <input className="ifield" style={{ flex:1, borderRadius:20, padding:"9px 12px", fontSize:12 }} placeholder="Type a message…" value={text} onChange={e => setText(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} />
        <button onClick={send} style={{ width:36, height:36, borderRadius:"50%", background:C.tealDark, border:"none", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>{Icon.send}</button>
      </div>
    </>
  );
  if (inline) return <>{content}</>;
  return (
    <div className="screen">
      <Appbar title={name} sub="Patient" onBack={onBack} />
      {content}
    </div>
  );
}

function HospitalInfoScreen({ onBack }) {
  return (
    <div className="screen">
      <Appbar title="Hospital Info" onBack={onBack} />
      <div style={{ flex:1, overflowY:"auto", WebkitOverflowScrolling:"touch", paddingBottom:20 }}>
        <div style={{ padding:"20px 18px 16px", background:"linear-gradient(135deg,#0D3D36,#1A8C7A)", textAlign:"center" }}>
          <div style={{ width:72, height:72, borderRadius:18, background:"white", display:"flex", alignItems:"center", justifyContent:"center", overflow:"hidden", padding:4, margin:"0 auto 10px", boxShadow:"0 4px 16px rgba(0,0,0,0.2)" }}>
            <img src={LOGO_URL} alt="MSH" style={{ width:"100%", height:"100%", objectFit:"contain" }} />
          </div>
          <div style={{ color:"white", fontSize:16, fontWeight:700 }}>Mother's Safe Hospital</div>
          <div style={{ color:"rgba(255,255,255,0.55)", fontSize:11 }}>Excellence in Prenatal Care since {HOSPITAL_INFO.founded}</div>
        </div>
        {[
          { title:"Contact", rows:[[Icon.phone,"Phone",HOSPITAL_INFO.phone],[Icon.alert,"Emergency",HOSPITAL_INFO.emergency],[Icon.mail,"Email",HOSPITAL_INFO.email]] },
          { title:"Location & Hours", rows:[[Icon.address,"Address",HOSPITAL_INFO.address],[Icon.clock,"Hours",HOSPITAL_INFO.hours],[Icon.bed,"Capacity",HOSPITAL_INFO.beds]] },
        ].map(({ title, rows }) => (
          <div key={title} className="psec" style={{ marginTop:10 }}>
            <div className="psec-hdr">{title}</div>
            {rows.map(([ic, l, v]) => <InfoRow key={l} icon={ic} label={l} value={v} />)}
          </div>
        ))}
        <div className="psec" style={{ marginTop:10 }}>
          <div className="psec-hdr">Our Specialties</div>
          <div style={{ padding:11, display:"flex", flexWrap:"wrap", gap:6 }}>
            {HOSPITAL_SPECIALTIES.map(s => <span key={s} className="chip-tag" style={{ background:C.tealLight, color:C.tealDark }}>{s}</span>)}
          </div>
        </div>
        <div className="psec" style={{ marginTop:10 }}>
          <div className="psec-hdr">Our Doctors</div>
          {HOSPITAL_DOCTORS_LIST.map(d => (
            <div key={d.name} className="tile" style={{ borderBottom:`1px solid ${C.border}` }}>
              <div className="avatar" style={{ width:34, height:34, fontSize:12 }}>{d.name[4]}</div>
              <div>
                <div style={{ fontSize:12, fontWeight:600 }}>{d.name}</div>
                <div style={{ fontSize:10, color:C.sub }}>{d.spec} · {d.exp}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AddVitalModal({ pid, ctx, onClose }) {
  const today = new Date().toISOString().slice(0,10);
  const [form, setForm] = useState({ date:today, sys:"", dia:"", wt:"", hr:"", fhr:"", notes:"" });
  const f = k => e => setForm(s => ({ ...s, [k]: e.target.value }));
  return (
    <div className="modal-ov" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-sheet">
        <div className="modal-handle" />
        <div style={{ fontSize:15, fontWeight:700, marginBottom:12 }}>Log Visit</div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:7, marginBottom:7 }}>
          <div><label className="ilabel">Date</label><input className="ifield" value={form.date} onChange={f("date")} /></div>
          <div><label className="ilabel">Weight (kg)</label><input className="ifield" type="number" value={form.wt} onChange={f("wt")} /></div>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:7, marginBottom:7 }}>
          <div><label className="ilabel">Systolic</label><input className="ifield" type="number" value={form.sys} onChange={f("sys")} /></div>
          <div><label className="ilabel">Diastolic</label><input className="ifield" type="number" value={form.dia} onChange={f("dia")} /></div>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:7, marginBottom:7 }}>
          <div><label className="ilabel">Heart Rate (bpm)</label><input className="ifield" type="number" value={form.hr} onChange={f("hr")} /></div>
          <div><label className="ilabel">Fetal HR (bpm)</label><input className="ifield" type="number" value={form.fhr} onChange={f("fhr")} /></div>
        </div>
        <label className="ilabel">Notes</label>
        <input className="ifield" value={form.notes} onChange={f("notes")} style={{ marginBottom:12 }} />
        <button className="btn btn-teal" onClick={() => { ctx.addVital(pid, { date:form.date, sys:parseInt(form.sys)||0, dia:parseInt(form.dia)||0, wt:parseFloat(form.wt)||0, hr:parseInt(form.hr)||0, fhr:parseInt(form.fhr)||0, notes:form.notes }); ctx.showToast("Visit logged!", C.green); onClose(); }}>{Icon.check} Save Visit</button>
      </div>
    </div>
  );
}

function EditListModal({ title, items, itemLabel, onSave, onClose }) {
  const [list, setList] = useState(items.map(i => ({ ...i })));
  return (
    <div className="modal-ov" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-sheet">
        <div className="modal-handle" />
        <div style={{ display:"flex", justifyContent:"space-between", marginBottom:10 }}>
          <span style={{ fontSize:15, fontWeight:700 }}>{title}</span>
          <button style={{ background:"none", border:"none", color:C.tealDark, fontWeight:700, cursor:"pointer", fontSize:12, display:"flex", alignItems:"center", gap:4 }} onClick={() => setList(s => [...s, { text:"", time:"" }])}>{Icon.plus} Add</button>
        </div>
        <div style={{ maxHeight:"44vh", overflowY:"auto" }}>
          {list.map((item, i) => (
            <div key={i} style={{ display:"flex", gap:5, marginBottom:7, alignItems:"center" }}>
              <input className="ifield" style={{ flex:2 }} placeholder={itemLabel} value={item.text} onChange={e => setList(l => l.map((x,j) => j===i ? { ...x, text:e.target.value } : x))} />
              <input className="ifield" style={{ flex:1 }} placeholder="Time" value={item.time} onChange={e => setList(l => l.map((x,j) => j===i ? { ...x, time:e.target.value } : x))} />
              <button style={{ background:"none", border:"none", color:C.rose, cursor:"pointer", flexShrink:0, display:"flex" }} onClick={() => setList(l => l.filter((_,j) => j!==i))}>{Icon.cross}</button>
            </div>
          ))}
        </div>
        <button className="btn btn-teal" style={{ marginTop:10 }} onClick={() => onSave(list.filter(i => i.text.trim()))}>{Icon.check} Save</button>
      </div>
    </div>
  );
}

function Appbar({ title, sub, onMenu, onBack, actions }) {
  return (
    <div className="appbar gradient-main" style={{ flexShrink:0 }}>
      {onBack && <button className="icon-btn" onClick={onBack}>{Icon.back}</button>}
      {onMenu && !onBack && <button className="icon-btn" onClick={onMenu}>{Icon.menu}</button>}
      <div style={{ flex:1 }}>
        <div style={{ color:"white", fontSize:14, fontWeight:700, lineHeight:1.2 }}>{title}</div>
        {sub && <div style={{ color:"rgba(255,255,255,0.6)", fontSize:10 }}>{sub}</div>}
      </div>
      {actions}
    </div>
  );
}

function Drawer({ isDoctor, name, sub, tab, onTab, onProfile, onHosp, onLogout, onClose }) {
  const docTabs = [["dash",Icon.home,"Dashboard"],["pats",Icon.patients,"Patients"],["appts",Icon.appts,"Appointments"],["msgs",Icon.chat,"Messages"]];
  const patTabs = [["home",Icon.home,"Home"],["appts",Icon.appts,"Appointments"],["chat",Icon.chat,"Chat with Doctor"],["profile",Icon.profile,"My Profile"]];
  const tabs = isDoctor ? docTabs : patTabs;
  return (
    <>
      <div className="drawer-ov" onClick={onClose} />
      <div className="drawer">
        <div className="d-hdr gradient-main">
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <div style={{ width:42, height:42, borderRadius:11, background:"rgba(255,255,255,0.15)", display:"flex", alignItems:"center", justifyContent:"center", color:"white" }}>{isDoctor ? Icon.doctor : Icon.patient}</div>
            <div>
              <div style={{ color:"white", fontWeight:700, fontSize:13 }}>{name}</div>
              <div style={{ color:"rgba(255,255,255,0.55)", fontSize:10 }}>{sub}</div>
            </div>
          </div>
        </div>
        {tabs.map(([k, icon, label]) => (
          <button key={k} className={`d-item ${tab===k?"active":""}`} onClick={() => onTab(k)}>
            <span style={{ color:tab===k ? C.tealDark : C.sub }}>{icon}</span>{label}
          </button>
        ))}
        <div className="d-sep" />
        {isDoctor && onProfile && <button className="d-item" onClick={onProfile}><span style={{ color:C.sub }}>{Icon.profile}</span>My Profile</button>}
        <button className="d-item" onClick={onHosp}>
          <img src={LOGO_URL} alt="" style={{ width:18, height:18, objectFit:"contain" }} />
          Hospital Info
        </button>
        <div style={{ flex:1 }} />
        <button className="d-item" style={{ color:C.rose, marginBottom:8 }} onClick={onLogout}><span style={{ color:C.rose }}>{Icon.logout}</span>Logout</button>
      </div>
    </>
  );
}

function BottomNav({ items, tab, onTab }) {
  return (
    <div className="bnav">
      {items.map(([k, icon, label]) => (
        <div key={k} className={`bnav-item ${tab===k?"active":""}`} onClick={() => onTab(k)}>
          <span className="bnav-icon">{icon}</span>{label}
        </div>
      ))}
    </div>
  );
}

function InfoRow({ icon, label, value, ic }) {
  return (
    <div className="irow">
      <span style={{ marginTop:1, flexShrink:0, color:ic || C.tealDark, display:"flex" }}>{icon}</span>
      <div>
        <div className="irow-lbl">{label}</div>
        <div className="irow-val">{value}</div>
      </div>
    </div>
  );
}

function WeekProgress({ week }) {
  const pct = Math.min(100, (week/40)*100);
  return (
    <div className="wkcard">
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <div>
          <div style={{ fontSize:9, color:C.sub, fontWeight:700, textTransform:"uppercase", letterSpacing:0.4 }}>Pregnancy Progress</div>
          <div style={{ fontSize:20, fontWeight:700, color:C.tealDark }}>Week {week}</div>
          <div style={{ fontSize:10, color:C.sub }}>{40-week} weeks remaining</div>
        </div>
        <div style={{ color:C.tealDark, opacity:0.7 }}>{Icon.progress}</div>
      </div>
      <div className="wkbar"><div className="wkfill" style={{ width:`${pct}%` }} /></div>
      <div style={{ display:"flex", justifyContent:"space-between", fontSize:9, color:C.sub, marginTop:3 }}>
        <span>Week 1</span><span>40 weeks</span>
      </div>
    </div>
  );
}

function PatTile({ p, onClick }) {
  const latest = p.vitals[p.vitals.length-1];
  const bp = latest ? bpStatus(latest.sys) : bpFromCategory(p.bpCategory || "normal");
  return (
    <div className="card card-m tile" onClick={onClick}>
      <div className="avatar" style={{ width:40, height:40 }}>{p.name[0]}</div>
      <div style={{ flex:1 }}>
        <div style={{ fontWeight:700, fontSize:13 }}>{p.name}</div>
        <div style={{ fontSize:10, color:C.sub }}>Week {p.week} · {p.blood} · Age {p.age}</div>
        {latest && <div style={{ fontSize:9, color:C.sub }}>BP: {latest.sys}/{latest.dia} mmHg</div>}
      </div>
      <span className="badge" style={{ background:bp.bg, color:bp.color }}>{bp.label}</span>
    </div>
  );
}

function ApptPill({ a }) {
  const [c, bg] = statusColor(a.status);
  return (
    <div className="card card-m" style={{ padding:"10px 12px", display:"flex", alignItems:"center" }}>
      <div style={{ flex:1 }}>
        <div style={{ fontWeight:600, fontSize:12 }}>{a.patName}</div>
        <div style={{ fontSize:10, color:C.sub }}>{a.reason}</div>
      </div>
      <span className="badge" style={{ background:bg, color:c }}>{a.status}</span>
    </div>
  );
}

function Empty({ icon, msg }) {
  return (
    <div className="empty">
      <div className="empty-icon" style={{ color:C.sub }}>{icon}</div>
      <div className="empty-txt">{msg}</div>
    </div>
  );
}

function SectionCard({ title, children }) {
  return (
    <div style={{ background:"white", borderRadius:12, marginBottom:10, overflow:"hidden", boxShadow:"0 1px 6px rgba(0,0,0,0.06)" }}>
      <div style={{ padding:"7px 12px", background:C.tealLighter, borderBottom:`1px solid ${C.border}`, fontSize:10, fontWeight:700, color:C.tealDark, textTransform:"uppercase", letterSpacing:0.4 }}>{title}</div>
      <div style={{ padding:"8px 10px", display:"flex", flexDirection:"column", gap:7 }}>{children}</div>
    </div>
  );
}

function FieldRow({ label, children }) {
  return (
    <div>
      <label className="ilabel">{label}</label>
      {children}
    </div>
  );
}

function DietMedHeader({ title, onEdit }) {
  return (
    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"10px 14px 3px" }}>
      <span style={{ fontSize:10, fontWeight:700, color:C.sub, textTransform:"uppercase", letterSpacing:0.4 }}>{title}</span>
      <button style={{ background:"none", border:"none", color:C.tealDark, fontSize:12, fontWeight:600, cursor:"pointer", display:"flex", alignItems:"center", gap:4 }} onClick={onEdit}>{Icon.edit} Edit</button>
    </div>
  );
}

function statusColor(status) {
  return { pending:[C.orange, C.orangeLight], accepted:[C.green, C.greenLight], denied:[C.rose, C.roseLight] }[status] || [C.sub, C.bg];
}
